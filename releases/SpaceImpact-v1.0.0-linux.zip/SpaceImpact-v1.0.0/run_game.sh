#!/bin/bash
chmod +x ./SpaceImpact
./SpaceImpact
